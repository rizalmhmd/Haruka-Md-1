import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, args, command, text }) => {
if (!text) throw `Linknya Mana?`
m.reply(wait)
  let res = await fetch(`https://api.xyroinee.xyz/api/downloader/youtube-audio?url=${text}&apikey=${global.xyro}`)
  let json = await res.json()
  let { title, views, channel, thumb, url, published} = json.data
  await conn.sendFile(m.chat, thumb, 'oh.jpg', `Title: ${title}
Views: ${views}
Channel: ${channel}
Publised: ${published}
`, m)
 await conn.sendAudio(m.chat, url, '', m)
}
handler.command = handler.help = ['yta', 'ytmp3']
handler.tags = ['downloader']
handler.limit = true
handler.premium = false
export default handler

