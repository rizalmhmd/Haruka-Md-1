import fetch from 'node-fetch'

let handler = async(m, { conn, text }) => {
  let res = await fetch(`https://api.ibeng.tech/api/anime/nekopoi?apikey=${global.ibeng}`)
  let json = await res.json()
  conn.sendFile(m.chat, json.data, 'bahan.mp4', `_Tcih Dasar Sangean_`, m)
}
handler.command = /^(randomnekopoi)$/i
handler.limit = true
handler.premium = true

export default handler
