import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, args, command, text }) => {
if (!text) throw `Linknya Mana?`
m.reply(wait)
  let res = await fetch(`https://api.ibeng.tech/api/downloader/tiktok?url=${text}&apikey=${global.ibeng}`)
  let json = await res.json()
  let cap = `*Username:* ${json.data.username}\n*Description:* ${json.data.description}
`
  conn.sendMessage(m.chat, { video: { url: json.data.video_HD }, caption: cap }, { quoted: m })
  }
handler.help = ['tiktok']
handler.tags = ['downloader']
handler.command = /^(tiktok|tt|ttdl|tiktokdl)$/i
handler.limit = true

export default handler